ACTUAL PORTFOLIO WEBSITE

Open index.html in a browser. All uploaded photos and video are already included in the assets folder.

Replace the contact placeholders and add your resume PDF as assets/Thayaparan_Mathivanan_Resume.pdf. The site is responsive and designed to match the supplied reference layout.
